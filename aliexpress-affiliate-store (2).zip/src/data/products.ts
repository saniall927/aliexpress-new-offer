import { Product } from '../types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: "ali-001",
    title: "Baseus 65W GaN5 Pro USB C Fast Charger & Power Strip",
    description: "The ultimate desktop charging station equipped with GaN5 technology, offering ultra-fast 65W charging across multiple ports. Perfect for charging your laptop, phone, and tablet simultaneously while occupying minimal desk space. Includes active temperature control and surge protection.",
    price: 24.99,
    originalPrice: 49.99,
    discount: 50,
    category: "Electronics",
    rating: 4.9,
    reviewsCount: 1420,
    imageUrl: "https://picsum.photos/seed/gancharger/600/600",
    aliexpressUrl: "https://www.aliexpress.com/item/1005005847321942.html",
    specifications: {
      "Brand Name": "Baseus",
      "Model": "GaN5 Pro 65W Desktop Station",
      "Output Interface": "2 x Type-C, 2 x USB-A, 1 x AC Outlet",
      "Input": "100-240V / 50-60Hz",
      "Max Output Power": "65W Max",
      "Applied Fast Charge Protocols": "PD 3.0, QC 4.0+, PPS, AFC",
      "Power Source": "A.C. Source"
    },
    features: [
      "Upgraded GaN5 technology for 10% cooler operation and 5x faster speeds",
      "Unified desktop charging with 4 USB ports and a built-in AC outlet",
      "Intelligent power allocation dynamically splits 65W across devices",
      "Advanced safety features: over-voltage, over-current, and electrostatic protections",
      "Compact, travel-friendly design with a 1.5m thick extension cord"
    ],
    reviews: [
      { author: "Marc L.", rating: 5, date: "2026-06-15", comment: "Incredible charger! Charges my MacBook Pro 14 and iPhone at full speed. Safe and very well built." },
      { author: "Elena R.", rating: 5, date: "2026-06-20", comment: "Excellent desktop power strip. No more bulky adapters on my desk. Definitely recommended." },
      { author: "Alex K.", rating: 4, date: "2026-06-25", comment: "Very fast charging, but get slightly warm when using all 4 ports at once. Highly portable." }
    ],
    isFeatured: true
  },
  {
    id: "ali-002",
    title: "Lenovo LP40 Pro Wireless Bluetooth 5.3 Earbuds",
    description: "Experience premium sound with Lenovo's LP40 Pro. Features advanced Bluetooth 5.3 for a ultra-stable connection, low latency for gaming, dual stereo sound, and a comfortable ergonomic semi-in-ear design. Enjoy up to 20 hours of music playtime with the sleek charging case.",
    price: 11.49,
    originalPrice: 29.99,
    discount: 61,
    category: "Electronics",
    rating: 4.7,
    reviewsCount: 8400,
    imageUrl: "https://picsum.photos/seed/earbuds/600/600",
    aliexpressUrl: "https://www.aliexpress.com/item/1005004312894321.html",
    specifications: {
      "Brand Name": "Lenovo",
      "Model": "LP40 Pro Thinkplus",
      "Bluetooth Version": "V5.3",
      "Effective Distance": "≥ 10 Meters",
      "Horn Diameter": "Ø 13mm",
      "Battery Capacity": "30mAh (Earbuds), 250mAh (Charging Box)",
      "Play Time": "Approx. 5 Hours (Single Charge)"
    },
    features: [
      "Bluetooth 5.3 technology ensures lower power consumption and zero audio lag",
      "13mm dynamic drivers offer heavy bass and HD crystal-clear voice calls",
      "Ergonomic semi-in-ear style fits comfortably for hours of active use",
      "Smart touch controls: adjust volume, skip tracks, and activate voice assistants",
      "Type-C interface for lightning-fast charging of the companion case"
    ],
    reviews: [
      { author: "David P.", rating: 5, date: "2026-05-12", comment: "Unbelievable value for money! Sound is punchy, connects instantly to my Android. Recommended!" },
      { author: "Sonia G.", rating: 4, date: "2026-05-18", comment: "Fits perfectly. Mic quality is okay for phone calls. Music is loud and clear." }
    ],
    isFeatured: true
  },
  {
    id: "ali-003",
    title: "Xiaomi Mi Band 8 Smart Fitness Tracker with AMOLED Screen",
    description: "The standard in active fitness monitoring. The Mi Band 8 features a beautiful, ultra-fluid 60Hz AMOLED display, comprehensive sleep tracking, 24/7 blood oxygen (SpO2) and heart-rate monitoring, and over 150 professional sport modes. Newly designed quick-release straps allow versatile wearing options.",
    price: 34.99,
    originalPrice: 59.99,
    discount: 41,
    category: "Smart Home",
    rating: 4.8,
    reviewsCount: 3450,
    imageUrl: "https://picsum.photos/seed/miband/600/600",
    aliexpressUrl: "https://www.aliexpress.com/item/1005005423891043.html",
    specifications: {
      "Brand Name": "Xiaomi",
      "Model": "Mi Smart Band 8",
      "Screen": "1.62\" AMOLED, 60Hz Refresh Rate",
      "Resolution": "192 x 490 pixels, up to 600 nits brightness",
      "Water Resistance": "5ATM (up to 50 Meters)",
      "Sensors": "6-axis High Precision Sensor, PPG Heart Rate, Ambient Light",
      "Battery Life": "Up to 16 Days (Typical Use)"
    },
    features: [
      "Vibrant 1.62-inch AMOLED display with auto-brightness and dynamic 60Hz scroll rate",
      "Professional workout analysis with training load indicators and recovery estimation",
      "Fully tracks sleep cycles, stress levels, SpO2 levels, and female health metrics",
      "Brand-new quick-release mechanism: wear as a wrist band, a running shoe pod, or a necklace pendant",
      "Charges fully in just 1 hour with magnetic fast charging tech"
    ],
    reviews: [
      { author: "Hiroshi T.", rating: 5, date: "2026-06-02", comment: "The 60Hz screen is incredibly smooth. The battery lasts over two weeks on a single charge." },
      { author: "Emily B.", rating: 5, date: "2026-06-11", comment: "Excellent sleep tracking and very lightweight. The automatic brightness works beautifully." }
    ],
    isFeatured: true
  },
  {
    id: "ali-004",
    title: "RGB Hot-Swappable Mechanical Gaming Keyboard (84-Key Layout)",
    description: "A compact 75% mechanical keyboard designed for high-performance typing and gaming. Equipped with hot-swappable tactile linear red switches, custom pre-lubed stabilizers, gorgeous pre-programmed RGB lighting effects, and reliable dual-mode USB-C connectivity. Highly mod-friendly and customizable.",
    price: 38.50,
    originalPrice: 79.99,
    discount: 51,
    category: "Computer Accessories",
    rating: 4.8,
    reviewsCount: 920,
    imageUrl: "https://picsum.photos/seed/keyboard/600/600",
    aliexpressUrl: "https://www.aliexpress.com/item/1005005230987412.html",
    specifications: {
      "Keys Type": "Hot-swappable Mechanical Switches (3/5-pin compatible)",
      "Layout": "84-Key Compact 75% Layout",
      "Backlight": "Full 16.8M RGB Backlight Modes",
      "Keycaps": "Double-shot PBT Keycaps (OEM Profile)",
      "Connection": "Detachable Type-C USB Cable",
      "Anti-Ghosting": "Full Key N-Key Rollover (NKRO)"
    },
    features: [
      "Hot-swap PCB allows you to change 3-pin/5-pin mechanical switches with absolute ease",
      "Premium pre-lubricated stabilizers eliminate key rattles on larger space/enter keys",
      "Stunning RGB effects with adjustable speed and customizable per-key lighting profiles",
      "Durable double-shot PBT keycaps offer superior grease resistance and won't fade over time",
      "Ergonomic layout with dual-stage adjustable rubberized tilt feet for long gaming sessions"
    ],
    reviews: [
      { author: "Kevin S.", rating: 5, date: "2026-06-14", comment: "Out of the box, it sounds amazing! No spring ping. The pre-lubed switches are buttery smooth." },
      { author: "Arthur V.", rating: 4, date: "2026-06-22", comment: "Excellent entry-level custom keyboard. Very easy to pull switches and replace. Lighting is very bright!" }
    ]
  },
  {
    id: "ali-005",
    title: "Portable Full HD Mini Projector with Android 11 Smart TV",
    description: "Bring the cinema anywhere with this ultra-portable 1080P supported smart mini projector. Powered by Android 11, it allows you to stream YouTube, Netflix, and Disney+ natively. Featuring a unique 180° rotatable stand design, dual-band Wi-Fi 6, and automatic keystone correction.",
    price: 59.99,
    originalPrice: 149.99,
    discount: 60,
    category: "Electronics",
    rating: 4.6,
    reviewsCount: 1540,
    imageUrl: "https://picsum.photos/seed/projector/600/600",
    aliexpressUrl: "https://www.aliexpress.com/item/1005005912435421.html",
    specifications: {
      "System": "Android 11.0 TV System",
      "Native Resolution": "1280*720P (Supports 1080P and 4K decoding)",
      "Brightness": "200 ANSI Lumens",
      "Wireless Connectivity": "Dual-Band Wi-Fi 6 (2.4G/5G) + Bluetooth 5.0",
      "Projection Size": "40 to 130 Inches",
      "Projection Distance": "1.2 - 4.0 Meters",
      "Interface": "HDMI, USB, Audio Jack"
    },
    features: [
      "Built-in Android 11.0 App store lets you stream content without needing external dongles",
      "Flexible 180° tilt design projects movies onto walls, screens, or even the bedroom ceiling",
      "Auto-Keystone correction automatically aligns skewed angles into a perfect 16:9 box",
      "Advanced Wi-Fi 6 ensures ultra-smooth screen mirroring from Apple and Android phones",
      "Compact, lightweight cylinder body that fits comfortably in a shoulder bag"
    ],
    reviews: [
      { author: "Clara M.", rating: 5, date: "2026-05-29", comment: "Amazing little projector! I watch films on my bedroom ceiling. Bright enough for dimly lit rooms." },
      { author: "Sven J.", rating: 4, date: "2026-06-05", comment: "Android works fine, apps run smoothly. Resolution is crisp. Speaker is average, best connected to Bluetooth speaker." }
    ],
    isFeatured: true
  },
  {
    id: "ali-006",
    title: "Anker Soundcore Motion+ Hi-Res Bluetooth Speaker 30W",
    description: "Immerse yourself in high-resolution audio. The Soundcore Motion+ is loaded with Hi-Res Audio certification, ultra-wide frequency response, active 30W stereo output, custom EQ customization, and complete IPX7 waterproof certification. Perfect for both audiophiles and outdoor explorers.",
    price: 79.99,
    originalPrice: 119.99,
    discount: 33,
    category: "Electronics",
    rating: 4.9,
    reviewsCount: 2180,
    imageUrl: "https://picsum.photos/seed/speaker/600/600",
    aliexpressUrl: "https://www.aliexpress.com/item/1005003189324501.html",
    specifications: {
      "Brand Name": "Anker Soundcore",
      "Model": "Motion Plus (Motion+)",
      "Audio Power": "30 Watts RMS",
      "Frequency Range": "50Hz - 40kHz (Hi-Res Certified)",
      "Waterproof Level": "IPX7 Rating",
      "Battery Capacity": "6700mAh",
      "Playtime": "Up to 12 Hours"
    },
    features: [
      "Hi-Res Audio certified with Qualcomm aptX technology for lossless Bluetooth streaming",
      "Equipped with dual high-frequency tweeters, neodymium woofers, and passive bass radiators",
      "Proprietary BassUp technology amplifies low frequencies in real-time",
      "Customizable 9-band EQ via the soundcore app tailored to your taste",
      "IPX7 complete waterproof casing fully protects against downpours or pool drops"
    ],
    reviews: [
      { author: "Peter F.", rating: 5, date: "2026-06-03", comment: "The soundstage is massive! Best portable speaker under $100 easily. Highs are crisp, bass is tight." },
      { author: "Nadia T.", rating: 5, date: "2026-06-18", comment: "Very sturdy and the sound doesn't distort even at max volume. Recommended for outdoor picnics." }
    ]
  },
  {
    id: "ali-007",
    title: "Ergonomic 2.4G Rechargeable Wireless Vertical Mouse",
    description: "Say goodbye to wrist pain. This vertical mouse features a scientifically calculated ergonomic slope that keeps your hand and wrist in a natural handshake position. Equipped with a built-in rechargeable battery, adjustable DPI levels (800-2400), and dual-mode connectivity.",
    price: 13.99,
    originalPrice: 29.99,
    discount: 53,
    category: "Computer Accessories",
    rating: 4.6,
    reviewsCount: 1670,
    imageUrl: "https://picsum.photos/seed/mouse/600/600",
    aliexpressUrl: "https://www.aliexpress.com/item/1005004239841022.html",
    specifications: {
      "Type": "Ergonomic Optical Vertical Mouse",
      "Connection Type": "2.4Ghz Wireless + Bluetooth 5.0 Dual Mode",
      "DPI Sensitivity": "800 - 1200 - 1600 - 2400 Adjustable",
      "Battery Type": "Rechargeable 500mAh Lithium Battery",
      "Charging Port": "USB Type-C",
      "Buttons": "6 Buttons (Left, Right, Scroll, DPI, Forward, Backward)"
    },
    features: [
      "Ergonomic handshake vertical form factor decreases wrist muscle strain and fatigue",
      "Dual mode allows seamless switching between two devices via a toggle button",
      "Muted silent click switches allow quiet workspaces, ideal for libraries or offices",
      "Eco-friendly built-in rechargeable battery lasts up to 30 days per full charge",
      "Matte rubberized sweat-proof surface provides a highly comfortable, secure grip"
    ],
    reviews: [
      { author: "Jonathan O.", rating: 4, date: "2026-06-08", comment: "Took 2 days to get used to the handshake grip, but my RSI wrist pain is entirely gone now." },
      { author: "Chloe L.", rating: 5, date: "2026-06-21", comment: "Silent clicks, neat battery indicator, and feels great. Fits smaller to medium hands perfectly." }
    ]
  },
  {
    id: "ali-008",
    title: "Tuya Smart WiFi RGBIC LED Bedside Table Lamp",
    description: "Transform your room's atmosphere. This smart bedside lamp delivers millions of vibrant RGB color options and warm/cool white lighting. Controllable via the Smart Life app, Alexa, Google Home, or local touch keys. Fully syncs with music rhythms and custom alarm schedules.",
    price: 19.99,
    originalPrice: 39.99,
    discount: 50,
    category: "Smart Home",
    rating: 4.7,
    reviewsCount: 780,
    imageUrl: "https://picsum.photos/seed/smartlamp/600/600",
    aliexpressUrl: "https://www.aliexpress.com/item/1005005118742104.html",
    specifications: {
      "Control Protocol": "Wi-Fi 2.4GHz + Bluetooth (Tuya Ecosystem)",
      "Voltage": "DC 5V / 2A (USB Powered)",
      "Max Power": "10 Watts",
      "Luminous Colors": "RGBIC (Multi-color display) + Tunable Warm/Cool White",
      "Dimmable range": "1% - 100% Brightness",
      "Smart Integrations": "Alexa, Google Assistant, SmartLife, Tuya App"
    },
    features: [
      "Dynamic RGBIC tech displays multiple colors on a single cylinder lamp simultaneously",
      "Intelligent control: adjust colors, preset light scenes, or set automated timers via phone",
      "Voice activated: integrates smoothly with Amazon Alexa or Google Assistant",
      "Sound sensing syncs: watch lighting respond and dance in time with music or ambient voices",
      "Premium eye-comfort diffuser emits safe, flickering-free lighting, perfect for bedrooms"
    ],
    reviews: [
      { author: "Liam S.", rating: 5, date: "2026-05-19", comment: "Works perfectly with my Smart Life app. The colors are incredibly vibrant and dimming is smooth." },
      { author: "Mei L.", rating: 4, date: "2026-06-01", comment: "Nice table lamp. The music sync mode is very cool during movie nights. Easily connects to Google Home." }
    ]
  },
  {
    id: "ali-009",
    title: "Waterproof Anti-Theft Laptop Travel Backpack with USB Port",
    description: "Designed for modern commuters and travelers. Made of ultra-durable, waterproof Oxford fabric, this backpack features a dedicated TSA-friendly 15.6-inch laptop compartment, hidden anti-theft pockets, an integrated external USB port for on-the-go charging, and multi-layer storage organization.",
    price: 18.99,
    originalPrice: 39.99,
    discount: 53,
    category: "Fashion Accessories",
    rating: 4.8,
    reviewsCount: 1890,
    imageUrl: "https://picsum.photos/seed/backpack/600/600",
    aliexpressUrl: "https://www.aliexpress.com/item/1005004183204910.html",
    specifications: {
      "Material": "High-density Waterproof Oxford Cloth & Polyester Lining",
      "Capacity": "20 - 35 Liters",
      "Laptop Pocket Size": "Fits laptops up to 15.6 Inches",
      "Dimensions": "42 x 30 x 12 cm",
      "Weight": "0.78 kg",
      "USB Port": "Integrated external charging extension interface"
    },
    features: [
      "Waterproof, scratch-resistant fabric ensures internal contents stay dry in rainstorms",
      "Anti-theft layout: hidden back pocket keeps wallets, passports, and phones completely safe",
      "Comfort-first design: padded, multi-panel ventilated back mesh reduces shoulder strain",
      "Built-in external USB port connects inside to your power bank for seamless mobile charging",
      "Sturdy luggage strap securely anchors the pack on wheeled suitcase handles"
    ],
    reviews: [
      { author: "Diego V.", rating: 5, date: "2026-06-12", comment: "Amazing commuter pack. Lots of pockets, lightweight, and very professional looking. Worth every penny." },
      { author: "Sophie T.", rating: 5, date: "2026-06-25", comment: "Survived a heavy downpour in Tokyo and all my tech inside stayed bone dry. Truly waterproof!" }
    ]
  },
  {
    id: "ali-010",
    title: "Ultra-thin 10000mAh Portable Power Bank (PD 22.5W Fast Charge)",
    description: "Never run out of power. This extremely sleek, card-sized portable charger fits inside any pocket while packing a robust 10000mAh battery capacity. Equipped with intelligent LCD percentage power display, 22.5W Power Delivery (PD) fast charging, and dual output ports.",
    price: 15.49,
    originalPrice: 29.99,
    discount: 48,
    category: "Electronics",
    rating: 4.7,
    reviewsCount: 2240,
    imageUrl: "https://picsum.photos/seed/powerbank/600/600",
    aliexpressUrl: "https://www.aliexpress.com/item/1005005012489312.html",
    specifications: {
      "Battery Type": "Li-polymer Battery",
      "Capacity": "10000mAh / 3.7V (37Wh)",
      "Output Ports": "1 x USB Type-C (Bi-directional), 1 x USB-A",
      "Max Power Speed": "PD 22.5W Max",
      "Display": "Digital LED Power Level Percentage Display",
      "Thickness": "Only 14mm Ultra-slim"
    },
    features: [
      "Card-sized format, weighs only 180g, making it the perfect everyday-carry companion",
      "22.5W fast charging juices up standard iPhones or Androids to 50% in just 30 minutes",
      "Integrated smart digital display shows exact remaining power down to 1%",
      "Multi-protect safety core checks thermals and prevents over-charging automatically",
      "Dual port outputs support charging two gadgets at the exact same time"
    ],
    reviews: [
      { author: "Sarah H.", rating: 5, date: "2026-05-30", comment: "So small! It's the size of a pack of cards and charges my iPhone 15 almost twice. Love the LED indicator." },
      { author: "Ravi G.", rating: 4, date: "2026-06-14", comment: "Charges quickly, very slim. Included USB cable is a bit short, but works great with my own USB-C cord." }
    ]
  }
];

export const CATEGORIES = [
  "All",
  "Electronics",
  "Smart Home",
  "Computer Accessories",
  "Fashion Accessories"
];
