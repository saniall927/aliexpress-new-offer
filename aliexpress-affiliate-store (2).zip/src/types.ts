export interface Review {
  author: string;
  rating: number;
  date: string;
  comment: string;
}

export interface Product {
  id: string;
  title: string;
  description: string;
  price: number;
  originalPrice: number;
  discount: number; // Percentage, e.g. 45 for 45% off
  category: string;
  rating: number;
  reviewsCount: number;
  imageUrl: string;
  aliexpressUrl: string; // The base aliexpress link
  specifications: Record<string, string>;
  features: string[];
  reviews: Review[];
  isCustom?: boolean;
  isFeatured?: boolean;
}

export interface AffiliateConfig {
  trackingId: string; // e.g. "my_affiliate_id" or "?subid=xyz"
  trackingParamName: string; // e.g. "subid" or "tag" or "dl_target_url"
  appendMethod: 'param' | 'replace' | 'custom_template';
  customTemplate: string; // e.g. "https://s.click.aliexpress.com/e/_xxx?subid={id}&dl_target_url={url}"
  showAffiliateDisclosure: boolean;
  disclosureText: string;
}

export interface SEOMeta {
  title: string;
  description: string;
  keywords: string;
  author: string;
  ogImage: string;
}
