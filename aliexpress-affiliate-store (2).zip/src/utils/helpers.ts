import { AffiliateConfig, Product } from '../types';

export function getAffiliateLink(baseLink: string, config: AffiliateConfig): string {
  if (!config.trackingId) return baseLink;
  
  if (config.appendMethod === 'param') {
    const cleanUrl = baseLink.split('?')[0]; // Remove existing parameters for a cleaner look if desired, or keep them
    // Let's keep original parameters and append our tracking ID
    const separator = baseLink.includes('?') ? '&' : '?';
    return `${baseLink}${separator}${config.trackingParamName}=${encodeURIComponent(config.trackingId)}`;
  } else if (config.appendMethod === 'custom_template' && config.customTemplate) {
    let tpl = config.customTemplate;
    // Replace placeholders: {url} with baseLink, {id} with trackingId
    tpl = tpl.replace(/{url}/g, encodeURIComponent(baseLink));
    tpl = tpl.replace(/{id}/g, encodeURIComponent(config.trackingId));
    return tpl;
  }
  
  return baseLink;
}

export function formatPrice(price: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD'
  }).format(price);
}

// Generates dynamic meta HTML code for head tags
export function generateMetaHTML(seo: { title: string; description: string; keywords: string; author: string; ogImage: string }): string {
  return `<!-- SEO Primary Meta Tags -->
<title>${escapeHTML(seo.title)}</title>
<meta name="title" content="${escapeHTML(seo.title)}" />
<meta name="description" content="${escapeHTML(seo.description)}" />
<meta name="keywords" content="${escapeHTML(seo.keywords)}" />
<meta name="author" content="${escapeHTML(seo.author)}" />

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website" />
<meta property="og:title" content="${escapeHTML(seo.title)}" />
<meta property="og:description" content="${escapeHTML(seo.description)}" />
<meta property="og:image" content="${escapeHTML(seo.ogImage)}" />

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image" />
<meta property="twitter:title" content="${escapeHTML(seo.title)}" />
<meta property="twitter:description" content="${escapeHTML(seo.description)}" />
<meta property="twitter:image" content="${escapeHTML(seo.ogImage)}" />`;
}

function escapeHTML(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
