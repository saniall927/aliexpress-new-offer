import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Heart, 
  Sparkles, 
  Filter, 
  ArrowRight, 
  Trash2, 
  ShoppingBag, 
  Info, 
  Award, 
  ShieldCheck,
  Undo2,
  X
} from 'lucide-react';

import Navbar from './components/Navbar';
import ProductCard from './components/ProductCard';
import ProductModal from './components/ProductModal';
import AffiliateConfigPanel from './components/AffiliateConfigPanel';
import SEOConfigPanel from './components/SEOConfigPanel';
import Footer from './components/Footer';

import { Product, AffiliateConfig, SEOMeta } from './types';
import { INITIAL_PRODUCTS, CATEGORIES } from './data/products';

// Default system configurations
const DEFAULT_AFFILIATE_CONFIG: AffiliateConfig = {
  trackingId: 'affiliate_store_2026',
  trackingParamName: 'subid',
  appendMethod: 'param',
  customTemplate: 'https://s.click.aliexpress.com/e/_xxx?subid={id}&dl_target_url={url}',
  showAffiliateDisclosure: true,
  disclosureText: 'Disclosure: As an AliExpress Associate, we earn from qualifying purchases. This means we may receive a small commission when you click buy links on our site, at absolutely zero additional cost to you. We only curate products with a high volume of positive consumer ratings.'
};

const DEFAULT_SEO_META: SEOMeta = {
  title: 'Curated AliExpress Deals & Bestsellers | Smart Affiliate Shop',
  description: 'Hand-picked premium AliExpress gadgets, accessories, and home innovations. Enjoy massive discounts, global free shipping, and complete AliExpress buyer protections.',
  keywords: 'aliexpress, affiliate store, gadget reviews, best smart home, budget tech accessories, keyboard mechanical',
  author: 'Affiliate Curator',
  ogImage: 'https://picsum.photos/seed/affiliatethumb/1200/630'
};

export default function App() {
  // Theme state
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('alistore_dark_mode');
    return saved ? JSON.parse(saved) : false;
  });

  // Tab navigation state: 'shop' | 'wishlist' | 'affiliate' | 'seo'
  const [currentTab, setCurrentTab] = useState<'shop' | 'wishlist' | 'affiliate' | 'seo'>('shop');

  // Search and filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortBy, setSortBy] = useState<string>('best_match');

  // Products Database (CMS-backed state)
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = localStorage.getItem('alistore_products_db');
    return saved ? JSON.parse(saved) : INITIAL_PRODUCTS;
  });

  // Wishlist array of product IDs
  const [wishlist, setWishlist] = useState<string[]>(() => {
    const saved = localStorage.getItem('alistore_wishlist');
    return saved ? JSON.parse(saved) : [];
  });

  // Affiliate Config state
  const [affiliateConfig, setAffiliateConfig] = useState<AffiliateConfig>(() => {
    const saved = localStorage.getItem('alistore_affiliate_config');
    return saved ? JSON.parse(saved) : DEFAULT_AFFILIATE_CONFIG;
  });

  // SEO configuration state
  const [seoMeta, setSeoMeta] = useState<SEOMeta>(() => {
    const saved = localStorage.getItem('alistore_seo_config');
    return saved ? JSON.parse(saved) : DEFAULT_SEO_META;
  });

  // Product selected for detail modal view
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Apply dark mode class to root HTML elements
  useEffect(() => {
    const root = document.documentElement;
    if (darkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    localStorage.setItem('alistore_dark_mode', JSON.stringify(darkMode));
  }, [darkMode]);

  // Persist wishlist to localStorage
  useEffect(() => {
    localStorage.setItem('alistore_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  // Toggle wishlist items
  const handleToggleWishlist = (product: Product) => {
    setWishlist((prev) => {
      if (prev.includes(product.id)) {
        return prev.filter((id) => id !== product.id);
      } else {
        return [...prev, product.id];
      }
    });
  };

  // Clear entire wishlist
  const handleClearWishlist = () => {
    setWishlist([]);
  };

  // Modify Affiliate Config
  const handleUpdateAffiliateConfig = (newConfig: AffiliateConfig) => {
    setAffiliateConfig(newConfig);
    localStorage.setItem('alistore_affiliate_config', JSON.stringify(newConfig));
  };

  // Modify SEO Meta Config
  const handleUpdateSEO = (newSEO: SEOMeta) => {
    setSeoMeta(newSEO);
    localStorage.setItem('alistore_seo_config', JSON.stringify(newSEO));
    
    // Dynamically update document title for SPA feel
    document.title = newSEO.title;
  };

  // Set default page title initially
  useEffect(() => {
    document.title = seoMeta.title;
  }, [seoMeta.title]);

  // CMS: Add new product
  const handleAddProduct = (newProduct: Product) => {
    const updated = [newProduct, ...products];
    setProducts(updated);
    localStorage.setItem('alistore_products_db', JSON.stringify(updated));
  };

  // CMS: Delete a product
  const handleDeleteProduct = (productId: string) => {
    const updated = products.filter((p) => p.id !== productId);
    setProducts(updated);
    localStorage.setItem('alistore_products_db', JSON.stringify(updated));
    
    // Remove from wishlist too if deleted
    if (wishlist.includes(productId)) {
      setWishlist((prev) => prev.filter((id) => id !== productId));
    }
  };

  // CMS: Reset products list to defaults
  const handleResetProducts = () => {
    if (window.confirm("Are you absolutely sure you want to reset the catalog? All custom additions and imports will be permanently deleted.")) {
      setProducts(INITIAL_PRODUCTS);
      localStorage.setItem('alistore_products_db', JSON.stringify(INITIAL_PRODUCTS));
      setWishlist([]);
    }
  };

  // CMS: Import products from pasted JSON text
  const handleImportProducts = (productsJson: string): boolean => {
    try {
      const parsed = JSON.parse(productsJson);
      if (Array.isArray(parsed)) {
        // Simple structural validation check
        const isValid = parsed.every((item) => {
          return item.id && item.title && item.price && item.aliexpressUrl && item.imageUrl;
        });

        if (isValid) {
          setProducts(parsed);
          localStorage.setItem('alistore_products_db', JSON.stringify(parsed));
          return true;
        }
      }
      return false;
    } catch (e) {
      return false;
    }
  };

  // Filter products based on search query and category tab selections
  const filteredProducts = products.filter((p) => {
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    
    const query = searchQuery.toLowerCase().trim();
    const matchesSearch = !query || 
      p.title.toLowerCase().includes(query) || 
      p.description.toLowerCase().includes(query) ||
      p.category.toLowerCase().includes(query) ||
      (p.specifications && Object.entries(p.specifications).some(([k, v]) => 
        k.toLowerCase().includes(query) || String(v).toLowerCase().includes(query)
      ));

    return matchesCategory && matchesSearch;
  });

  // Sort filtered output
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'price_low') {
      return a.price - b.price;
    }
    if (sortBy === 'price_high') {
      return b.price - a.price;
    }
    if (sortBy === 'discount') {
      return b.discount - a.discount;
    }
    if (sortBy === 'rating') {
      return b.rating - a.rating;
    }
    return 0; // 'best_match' (original order)
  });

  // Wishlist item entities
  const wishlistedProductItems = products.filter((p) => wishlist.includes(p.id));

  return (
    <div className={`min-h-screen flex flex-col bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-50 transition-colors duration-300 ${darkMode ? 'dark' : ''}`}>
      
      {/* Top Navigation */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={(tab) => {
          setCurrentTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        wishlistCount={wishlist.length}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        darkMode={darkMode}
        toggleDarkMode={() => setDarkMode(!darkMode)}
      />

      {/* Main Container Stage */}
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          
          {/* TAB 1: CURATED SHOP */}
          {currentTab === 'shop' && (
            <motion.div
              key="shop-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="pb-16"
            >
              {/* Dynamic curated promotional banner */}
              <div className="relative bg-gradient-to-r from-orange-600 via-red-600 to-amber-600 dark:from-orange-950/40 dark:via-red-950/40 dark:to-amber-950/40 text-white overflow-hidden py-12 px-4 sm:px-6 lg:px-8 border-b border-orange-500/20 shadow-inner">
                <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-8 relative z-10">
                  <div className="max-w-2xl text-center md:text-left space-y-4">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/20 text-xs font-bold tracking-wider uppercase backdrop-blur-md">
                      <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin" />
                      Hand-Selected AliExpress Treasures
                    </span>
                    <h2 className="font-sans font-black text-3xl sm:text-4xl lg:text-5xl tracking-tight leading-none">
                      Stop Scrolling. <br />
                      Discover Curated Gems.
                    </h2>
                    <p className="text-slate-100 dark:text-slate-300 text-sm sm:text-base leading-relaxed">
                      We analyze ratings, verify specifications, filter reviews, and compile only genuine, high-quality electronics and lifestyle accessories directly from AliExpress. Safe purchases, fully protected by AliExpress Guarantee.
                    </p>
                    
                    <div className="pt-2 flex flex-wrap gap-3 justify-center md:justify-start text-xs font-semibold">
                      <span className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-black/20 backdrop-blur-sm">
                        <Award className="w-4 h-4 text-amber-400" />
                        Top Ratings (4.6+ Stars)
                      </span>
                      <span className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-black/20 backdrop-blur-sm">
                        <ShieldCheck className="w-4 h-4 text-emerald-400" />
                        Express Shipping Enabled
                      </span>
                    </div>
                  </div>

                  <div className="hidden lg:flex w-80 h-80 rounded-3xl bg-white/10 dark:bg-slate-900/40 backdrop-blur-md border border-white/20 p-6 flex-col justify-between shadow-2xl relative">
                    <div className="absolute -top-3 -right-3 w-16 h-16 bg-red-500 rounded-2xl flex items-center justify-center font-bold text-white shadow-lg text-sm border-2 border-white rotate-12">
                      Up to <br /> 60% Off
                    </div>

                    <div className="flex justify-between items-start">
                      <span className="text-[10px] uppercase font-bold tracking-widest text-orange-200">Featured Highlight</span>
                      <span className="bg-emerald-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded">HOT PRICE</span>
                    </div>

                    <div>
                      <h4 className="font-sans font-extrabold text-lg leading-tight mt-2 text-white">
                        Baseus 65W GaN5 Pro Charger
                      </h4>
                      <p className="text-xs text-orange-100 line-clamp-2 mt-1">
                        Upgrade to GaN5 fast charging station. 50% discount active now.
                      </p>
                    </div>

                    <div className="flex justify-between items-baseline pt-4 border-t border-white/10">
                      <div>
                        <span className="text-[10px] block text-orange-200 line-through">$49.99</span>
                        <span className="text-2xl font-black">$24.99</span>
                      </div>
                      <button 
                        onClick={() => {
                          const item = products.find(p => p.id === 'ali-001');
                          if (item) setSelectedProduct(item);
                        }}
                        className="py-2 px-4 bg-white text-orange-600 hover:bg-slate-100 rounded-xl font-bold text-xs shadow transition-all flex items-center gap-1"
                      >
                        Details <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Floating decor ambient lights */}
                <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
                <div className="absolute bottom-0 left-0 w-80 h-80 bg-red-600/10 rounded-full blur-3xl -ml-24 -mb-24"></div>
              </div>

              {/* Filtering Rail & Sort Panel */}
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-10">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
                  
                  {/* Category Filter Chips */}
                  <div className="flex items-center gap-1.5 overflow-x-auto py-1 scrollbar-none flex-grow" id="category-selector">
                    <span className="text-slate-400 text-xs font-bold uppercase tracking-wider mr-2 hidden lg:inline flex-shrink-0">
                      Categories:
                    </span>
                    {CATEGORIES.map((cat) => (
                      <button
                        key={cat}
                        id={`category-btn-${cat.toLowerCase().replace(/\s+/g, '-')}`}
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all flex-shrink-0 ${
                          selectedCategory === cat
                            ? 'bg-orange-600 text-white shadow-sm shadow-orange-600/10'
                            : 'bg-white border border-slate-200 text-slate-600 hover:border-slate-300 dark:bg-slate-900 dark:border-slate-800 dark:text-slate-300 dark:hover:border-slate-700'
                        }`}
                      >
                        {cat}
                      </button>
                    ))}
                  </div>

                  {/* Sorting dropdown */}
                  <div className="flex items-center gap-2 justify-end">
                    <label className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase flex items-center gap-1">
                      <Filter className="w-3.5 h-3.5" />
                      <span>Sort:</span>
                    </label>
                    <select
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value)}
                      className="px-3 py-1.5 border border-slate-200 rounded-xl bg-white text-slate-800 dark:bg-slate-900 dark:border-slate-800 dark:text-slate-200 focus:outline-none text-xs font-bold shadow-sm cursor-pointer"
                    >
                      <option value="best_match">Best Curations</option>
                      <option value="price_low">Price: Low to High</option>
                      <option value="price_high">Price: High to Low</option>
                      <option value="discount">Biggest Discount</option>
                      <option value="rating">Top Rated Only</option>
                    </select>
                  </div>

                </div>

                {/* Search result indicator query bar */}
                {searchQuery && (
                  <div className="mt-4 flex items-center justify-between p-3 bg-orange-50/50 dark:bg-orange-950/10 rounded-xl border border-orange-100/50 dark:border-orange-900/30 text-xs text-orange-850 dark:text-orange-400">
                    <p className="font-semibold">
                      Showing results for search: <span className="font-mono bg-white dark:bg-slate-900 px-1.5 py-0.5 rounded border border-orange-200 dark:border-orange-800">"{searchQuery}"</span>
                    </p>
                    <button 
                      onClick={() => setSearchQuery('')}
                      className="text-orange-600 dark:text-orange-400 hover:underline font-bold"
                    >
                      Clear Search Filter
                    </button>
                  </div>
                )}

                {/* Curated Products Showcase Grid */}
                {sortedProducts.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mt-8" id="products-grid">
                    {sortedProducts.map((p) => (
                      <div key={p.id}>
                        <ProductCard
                          product={p}
                          onViewDetails={(prod) => setSelectedProduct(prod)}
                          isWishlisted={wishlist.includes(p.id)}
                          onToggleWishlist={handleToggleWishlist}
                          affiliateConfig={affiliateConfig}
                        />
                      </div>
                    ))}
                  </div>
                ) : (
                  /* No Matching Products State */
                  <div className="text-center py-20 px-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm mt-8 max-w-lg mx-auto">
                    <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mx-auto mb-4">
                      <ShoppingBag className="w-8 h-8" />
                    </div>
                    <h3 className="font-sans font-black text-lg text-slate-800 dark:text-white leading-tight">No Curated Items Match</h3>
                    <p className="text-xs text-slate-400 dark:text-slate-500 mt-2 max-w-sm mx-auto leading-relaxed">
                      We couldn't find any products fitting that keyword or category filter. Try clearing filters or adding custom products in the Affiliate Portal!
                    </p>
                    <button
                      onClick={() => {
                        setSelectedCategory('All');
                        setSearchQuery('');
                      }}
                      className="mt-5 px-5 py-2.5 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold transition-all shadow"
                    >
                      Clear All Search Filters
                    </button>
                  </div>
                )}

              </div>
            </motion.div>
          )}

          {/* TAB 2: MY WISHLIST */}
          {currentTab === 'wishlist' && (
            <motion.div
              key="wishlist-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8"
              id="wishlist-view-stage"
            >
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between border-b border-slate-200 dark:border-slate-800 pb-5 mb-8 gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-red-100 text-red-600 dark:bg-red-500/10 dark:text-red-400 flex items-center justify-center">
                    <Heart className="w-5.5 h-5.5 fill-red-500 text-red-500" />
                  </div>
                  <div>
                    <h1 className="font-sans font-black text-2xl sm:text-3xl text-slate-900 dark:text-white tracking-tight">
                      My Curated Wishlist
                    </h1>
                    <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
                      Your saved list of high-grade AliExpress items ready for checkout.
                    </p>
                  </div>
                </div>

                {wishlistedProductItems.length > 0 && (
                  <button
                    onClick={handleClearWishlist}
                    className="py-2.5 px-4 text-xs font-bold text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20 border border-red-200 dark:border-red-900/40 rounded-xl transition-all flex items-center gap-1.5 self-start"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Clear Wishlist ({wishlistedProductItems.length})</span>
                  </button>
                )}
              </div>

              {/* Grid content */}
              {wishlistedProductItems.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                  {wishlistedProductItems.map((p) => (
                    <div key={p.id}>
                      <ProductCard
                        product={p}
                        onViewDetails={(prod) => setSelectedProduct(prod)}
                        isWishlisted={true}
                        onToggleWishlist={handleToggleWishlist}
                        affiliateConfig={affiliateConfig}
                      />
                    </div>
                  ))}
                </div>
              ) : (
                /* Empty Wishlist Layout */
                <div className="text-center py-20 px-4 bg-white dark:bg-slate-900 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm max-w-md mx-auto mt-12">
                  <div className="w-16 h-16 rounded-full bg-red-50 dark:bg-red-950/30 text-red-500 flex items-center justify-center mx-auto mb-4">
                    <Heart className="w-8 h-8 fill-red-100 dark:fill-red-950" />
                  </div>
                  <h3 className="font-sans font-black text-lg text-slate-800 dark:text-white leading-tight">Your Saved List is Empty</h3>
                  <p className="text-xs text-slate-400 dark:text-slate-500 mt-2 leading-relaxed">
                    Browsing products? Click the floating heart badge on any card to save items on this page. They are backed up in your browser's memory!
                  </p>
                  <button
                    onClick={() => setCurrentTab('shop')}
                    className="mt-6 px-5 py-2.5 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold transition-all shadow flex items-center gap-1.5 mx-auto"
                  >
                    <ShoppingBag className="w-4 h-4" />
                    <span>Explore Products Catalogue</span>
                  </button>
                </div>
              )}
            </motion.div>
          )}

          {/* TAB 3: AFFILIATE DASHBOARD CONFIG */}
          {currentTab === 'affiliate' && (
            <motion.div
              key="affiliate-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
            >
              <AffiliateConfigPanel
                config={affiliateConfig}
                onChangeConfig={handleUpdateAffiliateConfig}
                products={products}
                onAddProduct={handleAddProduct}
                onDeleteProduct={handleDeleteProduct}
                onResetProducts={handleResetProducts}
                onImportProducts={handleImportProducts}
              />
            </motion.div>
          )}

          {/* TAB 4: SEO SIMULATOR */}
          {currentTab === 'seo' && (
            <motion.div
              key="seo-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
            >
              <SEOConfigPanel
                seo={seoMeta}
                onChangeSEO={handleUpdateSEO}
              />
            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* Slide-over/Backdrop Product Modal Details view */}
      <AnimatePresence>
        {selectedProduct && (
          <ProductModal
            product={selectedProduct}
            onClose={() => setSelectedProduct(null)}
            isWishlisted={wishlist.includes(selectedProduct.id)}
            onToggleWishlist={handleToggleWishlist}
            affiliateConfig={affiliateConfig}
          />
        )}
      </AnimatePresence>

      {/* Bottom Global Footer sitemap */}
      <Footer 
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        config={affiliateConfig}
      />

    </div>
  );
}
