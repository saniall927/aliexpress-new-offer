import React from 'react';
import { ShoppingBag, Info, Heart, ShieldAlert, Globe } from 'lucide-react';
import { AffiliateConfig } from '../types';

interface FooterProps {
  currentTab: 'shop' | 'wishlist' | 'affiliate' | 'seo';
  setCurrentTab: (tab: 'shop' | 'wishlist' | 'affiliate' | 'seo') => void;
  config: AffiliateConfig;
}

export default function Footer({
  currentTab,
  setCurrentTab,
  config
}: FooterProps) {
  return (
    <footer className="bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 transition-colors duration-300 mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          
          {/* Brand & About Column */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-2 cursor-pointer" onClick={() => setCurrentTab('shop')}>
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-500 via-orange-500 to-red-600 flex items-center justify-center text-white">
                <ShoppingBag className="w-4.5 h-4.5" />
              </div>
              <span className="font-sans font-black text-lg bg-gradient-to-r from-orange-600 to-red-600 dark:from-orange-500 dark:to-red-500 bg-clip-text text-transparent">
                AliExpress Affiliate Store
              </span>
            </div>
            
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed max-w-sm">
              Discover daily premium curated, vetted tech, lifestyle, and active home gadgets on AliExpress. We parse thousands of deals to compile only highly rated items, saving you search time and money.
            </p>
          </div>

          {/* Quick Sitemap Navigation Column */}
          <div>
            <h4 className="font-sans font-bold text-xs text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-3.5">
              Sitemap
            </h4>
            <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-350">
              <li>
                <button 
                  onClick={() => setCurrentTab('shop')}
                  className={`hover:text-orange-500 transition-colors ${currentTab === 'shop' ? 'text-orange-600 font-bold' : ''}`}
                >
                  Curated Catalog
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setCurrentTab('wishlist')}
                  className={`hover:text-orange-500 transition-colors ${currentTab === 'wishlist' ? 'text-orange-600 font-bold' : ''}`}
                >
                  Saved Wishlist
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setCurrentTab('affiliate')}
                  className={`hover:text-orange-500 transition-colors ${currentTab === 'affiliate' ? 'text-orange-600 font-bold' : ''}`}
                >
                  Affiliate Portal (CMS)
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setCurrentTab('seo')}
                  className={`hover:text-orange-500 transition-colors ${currentTab === 'seo' ? 'text-orange-600 font-bold' : ''}`}
                >
                  SEO Studio
                </button>
              </li>
            </ul>
          </div>

          {/* Independent Disclaimer Column */}
          <div className="space-y-3">
            <h4 className="font-sans font-bold text-xs text-slate-400 dark:text-slate-500 uppercase tracking-widest">
              Trademark Disclosure
            </h4>
            <p className="text-[11px] text-slate-400 dark:text-slate-500 leading-normal">
              This website is an independent curator and affiliate portal. AliExpress, AliExpress Logos, and trademarks are registered brands of Alibaba Group Holding Limited. We do not represent nor act on behalf of Alibaba.
            </p>
          </div>

        </div>

        {/* Affiliate Disclosure Statement Section (If Active) */}
        {config.showAffiliateDisclosure && (
          <div className="mt-8 p-4 rounded-2xl bg-orange-50/50 dark:bg-orange-950/10 border border-orange-100 dark:border-orange-900/30">
            <div className="flex gap-2.5 items-start">
              <ShieldAlert className="w-4 h-4 text-orange-600 dark:text-orange-500 flex-shrink-0 mt-0.5" />
              <div>
                <span className="text-xs font-bold text-orange-850 dark:text-orange-400 block mb-0.5">
                  Affiliate Disclosure Compliance Statement
                </span>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                  {config.disclosureText}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Bottom copyright details */}
        <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-400 dark:text-slate-500">
          <p>© 2026 AliExpress Premium Affiliate System. Built for premium static deployment.</p>
          <div className="flex gap-4">
            <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="hover:text-slate-600 dark:hover:text-slate-300">GitHub Pages Ready</a>
            <span>•</span>
            <span className="flex items-center gap-1"><Globe className="w-3.5 h-3.5 text-emerald-500" /> Host Globally</span>
          </div>
        </div>

      </div>
    </footer>
  );
}
