import React, { useState } from 'react';
import { 
  Settings, 
  Plus, 
  Trash2, 
  RotateCcw, 
  Download, 
  Upload, 
  Check, 
  AlertCircle, 
  Info, 
  ExternalLink,
  Code,
  Save,
  HelpCircle,
  ShoppingBag
} from 'lucide-react';
import { Product, AffiliateConfig } from '../types';
import { getAffiliateLink } from '../utils/helpers';

interface AffiliateConfigPanelProps {
  config: AffiliateConfig;
  onChangeConfig: (newConfig: AffiliateConfig) => void;
  products: Product[];
  onAddProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
  onResetProducts: () => void;
  onImportProducts: (productsJson: string) => boolean;
}

export default function AffiliateConfigPanel({
  config,
  onChangeConfig,
  products,
  onAddProduct,
  onDeleteProduct,
  onResetProducts,
  onImportProducts
}: AffiliateConfigPanelProps) {
  // Config States
  const [trackingId, setTrackingId] = useState(config.trackingId);
  const [trackingParamName, setTrackingParamName] = useState(config.trackingParamName);
  const [appendMethod, setAppendMethod] = useState(config.appendMethod);
  const [customTemplate, setCustomTemplate] = useState(config.customTemplate);
  const [showDisclosure, setShowDisclosure] = useState(config.showAffiliateDisclosure);
  const [disclosureText, setDisclosureText] = useState(config.disclosureText);
  
  // Playground state
  const [testUrl, setTestUrl] = useState('https://www.aliexpress.com/item/1005005847321942.html');
  const [convertedTestUrl, setConvertedTestUrl] = useState('');

  // Form states for creating custom products
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState('Electronics');
  const [newDesc, setNewDesc] = useState('');
  const [newPrice, setNewPrice] = useState('');
  const [newOriginalPrice, setNewOriginalPrice] = useState('');
  const [newImgUrl, setNewImgUrl] = useState('');
  const [newAliUrl, setNewAliUrl] = useState('');
  const [newBrand, setNewBrand] = useState('');
  const [newFeature1, setNewFeature1] = useState('');
  const [newFeature2, setNewFeature2] = useState('');
  const [formSuccess, setFormSuccess] = useState('');
  const [formError, setFormError] = useState('');

  // Import/Export States
  const [importJsonText, setImportJsonText] = useState('');
  const [importSuccess, setImportSuccess] = useState(false);
  const [importError, setImportError] = useState('');
  const [isSaved, setIsSaved] = useState(false);

  // Trigger test URL conversion
  const handleTestConversion = () => {
    const mockConfig: AffiliateConfig = {
      trackingId,
      trackingParamName,
      appendMethod,
      customTemplate,
      showAffiliateDisclosure: showDisclosure,
      disclosureText
    };
    const res = getAffiliateLink(testUrl, mockConfig);
    setConvertedTestUrl(res);
  };

  // Save Config
  const handleSaveConfig = () => {
    onChangeConfig({
      trackingId,
      trackingParamName,
      appendMethod,
      customTemplate,
      showAffiliateDisclosure: showDisclosure,
      disclosureText
    });
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  // Handle creating a new product
  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setFormSuccess('');

    if (!newTitle || !newDesc || !newPrice || !newOriginalPrice || !newImgUrl || !newAliUrl) {
      setFormError('All asterisk (*) fields are strictly required.');
      return;
    }

    const priceNum = parseFloat(newPrice);
    const originalPriceNum = parseFloat(newOriginalPrice);

    if (isNaN(priceNum) || isNaN(originalPriceNum)) {
      setFormError('Price and Original Price must be valid numbers.');
      return;
    }

    const discountPercent = Math.round(((originalPriceNum - priceNum) / originalPriceNum) * 100);

    const newProduct: Product = {
      id: `custom-${Date.now()}`,
      title: newTitle,
      description: newDesc,
      price: priceNum,
      originalPrice: originalPriceNum,
      discount: discountPercent > 0 ? discountPercent : 0,
      category: newCategory,
      rating: 4.8, // default starting rating
      reviewsCount: 1,
      imageUrl: newImgUrl,
      aliexpressUrl: newAliUrl,
      specifications: {
        "Brand Name": newBrand || "Generic Curated",
        "Source": "AliExpress Curated Import",
        "Quality Index": "Excellent Certified"
      },
      features: [
        newFeature1 || "High durability and premium build quality",
        newFeature2 || "Fully tested and highly recommended by affiliate community"
      ],
      reviews: [
        { author: "Affiliate System", rating: 5, date: "2026-07-04", comment: "Item has been validated and added to the store showcase successfully." }
      ],
      isCustom: true
    };

    onAddProduct(newProduct);
    setFormSuccess('Product has been added to the store catalog successfully!');
    
    // Reset form
    setNewTitle('');
    setNewDesc('');
    setNewPrice('');
    setNewOriginalPrice('');
    setNewImgUrl('');
    setNewAliUrl('');
    setNewBrand('');
    setNewFeature1('');
    setNewFeature2('');

    setTimeout(() => setFormSuccess(''), 4000);
  };

  // Handle Export Catalogue as JSON
  const handleExportJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(products, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", "alistore-affiliate-products.json");
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  // Handle Import Catalogue JSON
  const handleImportJsonSubmit = () => {
    setImportError('');
    setImportSuccess(false);

    if (!importJsonText.trim()) {
      setImportError('Please paste some product JSON data first.');
      return;
    }

    const ok = onImportProducts(importJsonText);
    if (ok) {
      setImportSuccess(true);
      setImportJsonText('');
      setTimeout(() => setImportSuccess(false), 3000);
    } else {
      setImportError('Invalid JSON format. Make sure it contains a valid array of products fitting the schema.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in" id="affiliate-panel-root">
      
      {/* Dashboard Title Header */}
      <div className="mb-8 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-600 dark:bg-orange-500/10 dark:text-orange-400 flex items-center justify-center">
            <Settings className="w-5.5 h-5.5" />
          </div>
          <div>
            <h1 className="font-sans font-black text-2xl sm:text-3xl text-slate-900 dark:text-white tracking-tight">
              Affiliate Management Dashboard
            </h1>
            <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
              Configure your AliExpress tracking ID, manage products catalogue (CMS), and export databases.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Grid: Link Customization & Disclosures */}
        <div className="lg:col-span-7 space-y-8">
          
          {/* Tracking Configuration Card */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm">
            <h3 className="font-sans font-extrabold text-lg text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <span>1. Global URL Tracking Rules</span>
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1.5">
                  AliExpress Tracking ID / SubID Value
                </label>
                <input
                  type="text"
                  value={trackingId}
                  onChange={(e) => setTrackingId(e.target.value)}
                  placeholder="e.g. tracking_id_2026, my_portal_code"
                  className="w-full px-4 py-2.5 border border-slate-200 rounded-xl bg-slate-50 text-slate-900 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500/20 text-sm"
                />
                <p className="text-[11px] text-slate-400 dark:text-slate-500 mt-1">
                  This identifier will be inserted in every redirect link to attribute buyers back to your affiliate dashboard.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1.5">
                    Query Parameter Name
                  </label>
                  <input
                    type="text"
                    value={trackingParamName}
                    onChange={(e) => setTrackingParamName(e.target.value)}
                    placeholder="subid"
                    disabled={appendMethod !== 'param'}
                    className="w-full px-4 py-2.5 border border-slate-200 rounded-xl bg-slate-50 text-slate-900 disabled:opacity-50 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500/20 text-sm"
                  />
                  <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1">
                    Typically 'subid', 'tag', or 'trackingId'.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1.5">
                    Url Append Method
                  </label>
                  <select
                    value={appendMethod}
                    onChange={(e) => setAppendMethod(e.target.value as any)}
                    className="w-full px-4 py-2.5 border border-slate-200 rounded-xl bg-slate-50 text-slate-900 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500/20 text-sm"
                  >
                    <option value="param">Query Parameter Append</option>
                    <option value="custom_template">Template Redirect Link</option>
                  </select>
                </div>
              </div>

              {appendMethod === 'custom_template' && (
                <div className="p-3.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
                  <label className="block text-xs font-bold text-slate-600 dark:text-slate-400 mb-1">
                    Custom Redirection Template
                  </label>
                  <input
                    type="text"
                    value={customTemplate}
                    onChange={(e) => setCustomTemplate(e.target.value)}
                    placeholder="https://s.click.aliexpress.com/e/_xxx?subid={id}&dl_target_url={url}"
                    className="w-full px-4 py-2.5 border border-slate-200 rounded-xl bg-white text-slate-900 dark:bg-slate-900 dark:border-slate-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500/20 text-xs font-mono"
                  />
                  <div className="text-[10px] text-slate-400 dark:text-slate-500 space-y-1">
                    <p>Use placeholders inside your URL template structure:</p>
                    <ul className="list-disc list-inside space-y-0.5 pl-1">
                      <li><code className="font-bold">{`{id}`}</code>: Replaced with your Tracking ID.</li>
                      <li><code className="font-bold">{`{url}`}</code>: Replaced with the target product AliExpress URL.</li>
                    </ul>
                  </div>
                </div>
              )}

              {/* Disclosure Toggle */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <span className="font-bold text-sm text-slate-800 dark:text-slate-200 block">Legally-Compliant Affiliate Disclosure</span>
                    <span className="text-xs text-slate-400 dark:text-slate-500">Show a disclosure banner in footer / product modal (legally required by FTC/GDPR).</span>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      checked={showDisclosure} 
                      onChange={(e) => setShowDisclosure(e.target.checked)}
                      className="sr-only peer" 
                    />
                    <div className="w-11 h-6 bg-slate-200 dark:bg-slate-800 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-500"></div>
                  </label>
                </div>

                {showDisclosure && (
                  <textarea
                    value={disclosureText}
                    onChange={(e) => setDisclosureText(e.target.value)}
                    rows={2}
                    className="w-full p-3 border border-slate-200 rounded-xl bg-slate-50 text-slate-800 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white focus:outline-none text-xs"
                    placeholder="Enter FTC disclosure statement..."
                  />
                )}
              </div>

              {/* Save Rules Button */}
              <button
                onClick={handleSaveConfig}
                className="w-full py-3 bg-slate-900 text-white dark:bg-white dark:text-slate-900 rounded-xl font-bold text-sm hover:opacity-90 transition-all flex items-center justify-center gap-2 shadow-sm"
              >
                {isSaved ? <Check className="w-4 h-4 text-emerald-500" /> : <Save className="w-4 h-4" />}
                <span>{isSaved ? 'Config Rules Saved in System!' : 'Save & Compile Rules'}</span>
              </button>

            </div>
          </div>

          {/* Test Playground Converter */}
          <div className="bg-slate-50 dark:bg-slate-900/40 p-6 rounded-2xl border border-slate-200/55 dark:border-slate-800 shadow-inner">
            <h3 className="font-sans font-extrabold text-base text-slate-900 dark:text-white mb-2 flex items-center gap-2">
              <Code className="w-4.5 h-4.5 text-orange-500" />
              <span>Affiliate Link Playground (Live Converter)</span>
            </h3>
            <p className="text-xs text-slate-400 dark:text-slate-500 mb-4">
              Paste ANY AliExpress product page URL here to instantly test how your rules compile your live affiliate redirect.
            </p>

            <div className="space-y-3">
              <div>
                <input
                  type="text"
                  value={testUrl}
                  onChange={(e) => setTestUrl(e.target.value)}
                  placeholder="Paste test AliExpress URL..."
                  className="w-full px-4 py-2 border border-slate-200 rounded-xl bg-white text-slate-900 dark:bg-slate-900 dark:border-slate-800 dark:text-white focus:outline-none text-xs font-mono"
                />
              </div>

              <div className="flex gap-2">
                <button
                  onClick={handleTestConversion}
                  className="px-4 py-2 bg-orange-500 hover:bg-orange-600 text-white rounded-xl text-xs font-bold transition-all"
                >
                  Test Link Convert
                </button>
              </div>

              {convertedTestUrl && (
                <div className="p-3 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl">
                  <span className="text-[10px] text-slate-400 dark:text-slate-500 block font-bold mb-1 uppercase tracking-wide">Generated Link Output</span>
                  <code className="text-xs font-mono text-orange-600 dark:text-orange-400 break-all select-all">
                    {convertedTestUrl}
                  </code>
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Right Grid: Catalogue Management CMS & Export */}
        <div className="lg:col-span-5 space-y-8">
          
          {/* Add custom product card Form */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm">
            <h3 className="font-sans font-extrabold text-lg text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <span>2. Product Showcase CMS (Add Item)</span>
            </h3>

            <form onSubmit={handleCreateProduct} className="space-y-4">
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-1">
                    Category *
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 text-slate-850 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white text-xs"
                  >
                    <option value="Electronics">Electronics</option>
                    <option value="Smart Home">Smart Home</option>
                    <option value="Computer Accessories">Computer Accessories</option>
                    <option value="Fashion Accessories">Fashion Accessories</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-1">
                    Product Brand
                  </label>
                  <input
                    type="text"
                    value={newBrand}
                    onChange={(e) => setNewBrand(e.target.value)}
                    placeholder="e.g. Baseus, Xiaomi"
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 text-slate-950 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-1">
                  Product Title *
                </label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Baseus GaN Charger"
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 text-slate-950 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white text-xs"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-1">
                  Product Description *
                </label>
                <textarea
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  rows={2}
                  placeholder="Enter a brief, catchy description outlining specs..."
                  className="w-full p-3 border border-slate-200 rounded-xl bg-slate-50 text-slate-950 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-1">
                    Affiliate Sale Price ($) *
                  </label>
                  <input
                    type="text"
                    value={newPrice}
                    onChange={(e) => setNewPrice(e.target.value)}
                    placeholder="19.99"
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 text-slate-950 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white text-xs"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-1">
                    Original Price ($) *
                  </label>
                  <input
                    type="text"
                    value={newOriginalPrice}
                    onChange={(e) => setNewOriginalPrice(e.target.value)}
                    placeholder="39.99"
                    className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 text-slate-950 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-1">
                  Product Image URL *
                </label>
                <input
                  type="text"
                  value={newImgUrl}
                  onChange={(e) => setNewImgUrl(e.target.value)}
                  placeholder="https://picsum.photos/seed/gadget/600/600"
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 text-slate-950 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white text-xs"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase mb-1">
                  Base AliExpress Product URL *
                </label>
                <input
                  type="text"
                  value={newAliUrl}
                  onChange={(e) => setNewAliUrl(e.target.value)}
                  placeholder="https://www.aliexpress.com/item/..."
                  className="w-full px-3 py-2 border border-slate-200 rounded-xl bg-slate-50 text-slate-950 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <input
                  type="text"
                  value={newFeature1}
                  onChange={(e) => setNewFeature1(e.target.value)}
                  placeholder="Feature Bullet 1"
                  className="w-full px-3 py-1.5 border border-slate-200 rounded-xl bg-slate-50 text-slate-950 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white text-xs"
                />
                <input
                  type="text"
                  value={newFeature2}
                  onChange={(e) => setNewFeature2(e.target.value)}
                  placeholder="Feature Bullet 2"
                  className="w-full px-3 py-1.5 border border-slate-200 rounded-xl bg-slate-50 text-slate-950 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white text-xs"
                />
              </div>

              {formError && (
                <div className="p-2.5 bg-red-50 text-red-700 border border-red-200 rounded-lg text-xs flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {formSuccess && (
                <div className="p-2.5 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-lg text-xs flex items-center gap-1.5">
                  <Check className="w-4 h-4 flex-shrink-0" />
                  <span>{formSuccess}</span>
                </div>
              )}

              <button
                type="submit"
                className="w-full py-2.5 bg-gradient-to-r from-orange-500 to-red-600 text-white rounded-xl font-bold text-xs hover:opacity-90 transition-all flex items-center justify-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>Publish Product to Store</span>
              </button>

            </form>
          </div>

          {/* Database Backup & Catalog Reset */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-5">
            <div>
              <h3 className="font-sans font-extrabold text-sm text-slate-900 dark:text-white tracking-wide uppercase mb-1">
                Catalogue Backup & Control
              </h3>
              <p className="text-xs text-slate-400 dark:text-slate-500">
                You can download the current catalog JSON to preserve your changes, or restore defaults.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={handleExportJson}
                className="py-2 px-3 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export JSON</span>
              </button>

              <button
                onClick={onResetProducts}
                className="py-2 px-3 border border-red-200 text-red-600 dark:border-red-900/40 dark:text-red-400 hover:bg-red-50/50 dark:hover:bg-red-950/20 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Default</span>
              </button>
            </div>

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
              <label className="block text-[11px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2">
                Paste Catalog JSON to Import
              </label>
              
              <textarea
                value={importJsonText}
                onChange={(e) => setImportJsonText(e.target.value)}
                rows={2}
                placeholder="[ { 'id': 'ali-001', 'title': 'Baseus GaN...', ... } ]"
                className="w-full p-2.5 font-mono text-[10px] bg-slate-50 border border-slate-200 rounded-xl dark:bg-slate-950 dark:border-slate-800 dark:text-slate-300 focus:outline-none"
              />

              {importError && (
                <div className="mt-2 p-2 bg-red-50 text-red-700 rounded-lg text-[11px] flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>{importError}</span>
                </div>
              )}

              {importSuccess && (
                <div className="mt-2 p-2 bg-emerald-50 text-emerald-800 rounded-lg text-[11px] flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" />
                  <span>Catalog imported successfully!</span>
                </div>
              )}

              <button
                onClick={handleImportJsonSubmit}
                className="w-full mt-2.5 py-2 bg-slate-800 hover:bg-slate-900 dark:bg-slate-750 dark:hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Verify & Overwrite Catalog</span>
              </button>
            </div>

          </div>

        </div>

      </div>

      {/* Loaded Products Inventory list CMS */}
      <div className="mt-8 bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm">
        <h3 className="font-sans font-extrabold text-lg text-slate-900 dark:text-white mb-4">
          Current Curated Product Inventory ({products.length} Items)
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 dark:text-slate-500 uppercase font-bold tracking-wider">
                <th className="py-3 px-4">Item Details</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Direct Link</th>
                <th className="py-3 px-4">Sale Price</th>
                <th className="py-3 px-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="text-xs divide-y divide-slate-100 dark:divide-slate-800/50">
              {products.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20 transition-colors">
                  <td className="py-3 px-4 flex items-center gap-3">
                    <img 
                      src={p.imageUrl} 
                      alt="" 
                      className="w-8 h-8 rounded-lg object-cover flex-shrink-0" 
                      referrerPolicy="no-referrer"
                    />
                    <div className="max-w-[280px]">
                      <span className="font-bold text-slate-800 dark:text-slate-200 line-clamp-1">{p.title}</span>
                      <span className="text-[10px] text-slate-400 dark:text-slate-500">ID: {p.id} {p.isCustom && <span className="bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-400 text-[9px] px-1 rounded ml-1">Custom</span>}</span>
                    </div>
                  </td>
                  <td className="py-3 px-4 text-slate-500 dark:text-slate-400">
                    {p.category}
                  </td>
                  <td className="py-3 px-4">
                    <a 
                      href={p.aliexpressUrl} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="text-slate-400 hover:text-orange-500 dark:text-slate-500 font-mono text-[10px] break-all line-clamp-1 hover:underline flex items-center gap-1"
                    >
                      <span>AliExpress Page</span>
                      <ExternalLink className="w-3 h-3 flex-shrink-0" />
                    </a>
                  </td>
                  <td className="py-3 px-4 font-extrabold text-orange-600 dark:text-orange-500">
                    ${p.price.toFixed(2)}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <button
                      onClick={() => onDeleteProduct(p.id)}
                      className="p-1.5 text-slate-400 hover:text-red-500 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/20 rounded-lg transition-colors"
                      title="Remove Product"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
}
