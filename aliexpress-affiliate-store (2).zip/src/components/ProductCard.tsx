import React from 'react';
import { Star, Heart, ExternalLink, Eye, Info } from 'lucide-react';
import { Product, AffiliateConfig } from '../types';
import { getAffiliateLink, formatPrice } from '../utils/helpers';

interface ProductCardProps {
  product: Product;
  onViewDetails: (product: Product) => void;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  affiliateConfig: AffiliateConfig;
}

export default function ProductCard({
  product,
  onViewDetails,
  isWishlisted,
  onToggleWishlist,
  affiliateConfig
}: ProductCardProps) {
  const affiliateLink = getAffiliateLink(product.aliexpressUrl, affiliateConfig);

  // Render Star Ratings
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;

    for (let i = 1; i <= 5; i++) {
      if (i <= fullStars) {
        stars.push(<Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />);
      } else if (i === fullStars + 1 && hasHalfStar) {
        stars.push(
          <div key={i} className="relative inline-block">
            <Star className="w-3.5 h-3.5 text-slate-300 dark:text-slate-600" />
            <div className="absolute top-0 left-0 overflow-hidden w-1/2">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            </div>
          </div>
        );
      } else {
        stars.push(<Star key={i} className="w-3.5 h-3.5 text-slate-300 dark:text-slate-600" />);
      }
    }
    return stars;
  };

  return (
    <div 
      className="group flex flex-col bg-white dark:bg-slate-900 rounded-2xl overflow-hidden border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-md dark:hover:border-slate-700/80 transition-all duration-300 h-full"
      id={`product-card-${product.id}`}
    >
      {/* Product Image Stage */}
      <div className="relative aspect-square overflow-hidden bg-slate-50 dark:bg-slate-950 flex items-center justify-center">
        <img
          src={product.imageUrl}
          alt={product.title}
          referrerPolicy="no-referrer"
          className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500"
          id={`product-image-${product.id}`}
        />

        {/* Hot / Discount Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10 pointer-events-none">
          <span className="bg-red-600 text-white text-[11px] font-bold px-2 py-0.5 rounded-full shadow-sm">
            {product.discount}% OFF
          </span>
          {product.isFeatured && (
            <span className="bg-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm tracking-wider uppercase">
              Bestseller
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product);
          }}
          className={`absolute top-3 right-3 p-2 rounded-full border shadow-sm backdrop-blur-md transition-all duration-300 z-10 ${
            isWishlisted 
              ? 'bg-red-50 border-red-200 text-red-500 dark:bg-red-900/30 dark:border-red-800' 
              : 'bg-white/80 border-slate-200 text-slate-500 hover:text-red-500 dark:bg-slate-800/80 dark:border-slate-700 dark:text-slate-400'
          }`}
          id={`wishlist-toggle-${product.id}`}
          aria-label="Toggle wishlist"
        >
          <Heart className={`w-4 h-4 transition-transform duration-300 ${isWishlisted ? 'fill-red-500 scale-110' : 'group-hover:scale-105'}`} />
        </button>

        {/* Floating Quick Action overlay for desktop */}
        <div className="absolute inset-0 bg-slate-950/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
          <button
            onClick={() => onViewDetails(product)}
            className="px-3.5 py-1.5 bg-white text-slate-900 rounded-lg text-xs font-bold flex items-center gap-1.5 shadow-md hover:bg-slate-100 transition-all transform translate-y-2 group-hover:translate-y-0 duration-300"
          >
            <Eye className="w-3.5 h-3.5" />
            Quick View
          </button>
        </div>
      </div>

      {/* Product Information Body */}
      <div className="p-4 flex-1 flex flex-col">
        {/* Category tag */}
        <div className="text-[11px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider mb-1.5">
          {product.category}
        </div>

        {/* Product Title */}
        <h3 
          onClick={() => onViewDetails(product)}
          className="font-sans font-semibold text-sm text-slate-800 dark:text-slate-100 line-clamp-2 min-h-[40px] hover:text-orange-500 cursor-pointer transition-colors"
        >
          {product.title}
        </h3>

        {/* Ratings & Orders */}
        <div className="flex items-center gap-1.5 mt-2">
          <div className="flex items-center gap-0.5">
            {renderStars(product.rating)}
          </div>
          <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400">
            {product.rating}
          </span>
          <span className="text-[10px] text-slate-400 dark:text-slate-500">
            ({product.reviewsCount}+ sold)
          </span>
        </div>

        {/* Micro specs bullet for e-commerce realism */}
        <div className="mt-3 py-1 px-1.5 bg-slate-50 dark:bg-slate-800/30 rounded-lg flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <span className="truncate max-w-[120px] font-medium">
            {Object.keys(product.specifications)[0]}: {Object.values(product.specifications)[0]}
          </span>
          <span className="text-orange-600 dark:text-orange-400 font-bold flex items-center gap-0.5">
            <Info className="w-3 h-3" /> Info
          </span>
        </div>

        {/* Pricing Matrix */}
        <div className="mt-auto pt-4 flex items-baseline justify-between gap-2 border-t border-slate-100 dark:border-slate-800/50">
          <div className="flex flex-col">
            <span className="text-xs text-slate-400 dark:text-slate-500 line-through">
              {formatPrice(product.originalPrice)}
            </span>
            <span className="text-lg font-extrabold text-orange-600 dark:text-orange-500">
              {formatPrice(product.price)}
            </span>
          </div>
          
          <div className="text-emerald-600 dark:text-emerald-500 text-[10px] font-bold bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900/50 px-1.5 py-0.5 rounded-md">
            Save {formatPrice(product.originalPrice - product.price)}
          </div>
        </div>

        {/* Call to Actions */}
        <div className="grid grid-cols-2 gap-2 mt-4">
          <button
            onClick={() => onViewDetails(product)}
            className="w-full py-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700/80 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1"
          >
            Details
          </button>
          
          <a
            href={affiliateLink}
            target="_blank"
            rel="noopener noreferrer"
            id={`affiliate-link-${product.id}`}
            className="w-full py-2 bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700 text-white rounded-xl text-xs font-bold transition-all text-center flex items-center justify-center gap-1 shadow-sm shadow-orange-500/10 hover:shadow-md"
          >
            <span>Buy Now</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>

      </div>
    </div>
  );
}
