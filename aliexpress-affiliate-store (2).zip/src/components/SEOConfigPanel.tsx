import React, { useState } from 'react';
import { 
  Globe, 
  Search, 
  Copy, 
  Check, 
  Github, 
  Info, 
  ExternalLink, 
  FileCode, 
  Terminal,
  FileText
} from 'lucide-react';
import { SEOMeta } from '../types';
import { generateMetaHTML } from '../utils/helpers';

interface SEOConfigPanelProps {
  seo: SEOMeta;
  onChangeSEO: (newSEO: SEOMeta) => void;
}

export default function SEOConfigPanel({
  seo,
  onChangeSEO
}: SEOConfigPanelProps) {
  const [title, setTitle] = useState(seo.title);
  const [description, setDescription] = useState(seo.description);
  const [keywords, setKeywords] = useState(seo.keywords);
  const [author, setAuthor] = useState(seo.author);
  const [ogImage, setOgImage] = useState(seo.ogImage);

  const [copiedMeta, setCopiedMeta] = useState(false);
  const [copiedScript, setCopiedScript] = useState(false);
  const [previewDevice, setPreviewDevice] = useState<'desktop' | 'mobile'>('desktop');

  const handleSaveSEO = () => {
    onChangeSEO({
      title,
      description,
      keywords,
      author,
      ogImage
    });
  };

  const handleCopyMeta = () => {
    const metaHTML = generateMetaHTML({ title, description, keywords, author, ogImage });
    navigator.clipboard.writeText(metaHTML);
    setCopiedMeta(true);
    setTimeout(() => setCopiedMeta(false), 2000);
  };

  const packageJsonScript = `"scripts": {
  "predeploy": "npm run build",
  "deploy": "gh-pages -d dist"
}`;

  const handleCopyScript = () => {
    navigator.clipboard.writeText(packageJsonScript);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2000);
  };

  const compiledMetaCode = generateMetaHTML({ title, description, keywords, author, ogImage });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in" id="seo-panel-root">
      
      {/* Page Title Header */}
      <div className="mb-8 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-600 dark:bg-orange-500/10 dark:text-orange-400 flex items-center justify-center">
            <Globe className="w-5.5 h-5.5" />
          </div>
          <div>
            <h1 className="font-sans font-black text-2xl sm:text-3xl text-slate-900 dark:text-white tracking-tight">
              SEO Studio & Deployment Guide
            </h1>
            <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
              Simulate Google search rankings, design custom meta tags, and configure GitHub Pages deployment.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Form & Settings */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="font-sans font-extrabold text-base text-slate-900 dark:text-white mb-2">
              Meta Tag Configurator
            </h3>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1">
                  Search Engine Page Title
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => { setTitle(e.target.value); handleSaveSEO(); }}
                  maxLength={70}
                  className="w-full px-4 py-2 border border-slate-200 rounded-xl bg-slate-50 text-slate-900 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500/20 text-xs font-medium"
                />
                <div className="flex justify-between text-[10px] text-slate-400 dark:text-slate-500 mt-1">
                  <span>Ideally under 60 characters for indexing.</span>
                  <span className={title.length > 60 ? 'text-orange-500 font-bold' : ''}>{title.length}/70 chars</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1">
                  Meta Description
                </label>
                <textarea
                  value={description}
                  onChange={(e) => { setDescription(e.target.value); handleSaveSEO(); }}
                  maxLength={160}
                  rows={3}
                  className="w-full p-3 border border-slate-200 rounded-xl bg-slate-50 text-slate-900 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white focus:outline-none focus:ring-2 focus:ring-orange-500/20 text-xs font-medium"
                />
                <div className="flex justify-between text-[10px] text-slate-400 dark:text-slate-500 mt-1">
                  <span>A concise summary displayed in Google listings.</span>
                  <span className={description.length > 150 ? 'text-orange-500 font-bold' : ''}>{description.length}/160 chars</span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1">
                    Meta Keywords
                  </label>
                  <input
                    type="text"
                    value={keywords}
                    onChange={(e) => { setKeywords(e.target.value); handleSaveSEO(); }}
                    placeholder="aliexpress, affiliate, gadget deals"
                    className="w-full px-4 py-2 border border-slate-200 rounded-xl bg-slate-50 text-slate-900 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white focus:outline-none text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1">
                    Author Credit
                  </label>
                  <input
                    type="text"
                    value={author}
                    onChange={(e) => { setAuthor(e.target.value); handleSaveSEO(); }}
                    className="w-full px-4 py-2 border border-slate-200 rounded-xl bg-slate-50 text-slate-900 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white focus:outline-none text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-1">
                  Social Graph Image Link (OG:Image)
                </label>
                <input
                  type="text"
                  value={ogImage}
                  onChange={(e) => { setOgImage(e.target.value); handleSaveSEO(); }}
                  className="w-full px-4 py-2 border border-slate-200 rounded-xl bg-slate-50 text-slate-900 dark:bg-slate-800/50 dark:border-slate-700 dark:text-white focus:outline-none text-xs font-mono"
                />
                <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-1">
                  Used as rich preview card thumbnail on Facebook, Twitter, and messaging apps.
                </p>
              </div>

            </div>
          </div>

          {/* Social graph image preview card */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-3">
            <h4 className="font-sans font-bold text-xs text-slate-400 dark:text-slate-500 uppercase tracking-widest">
              Social Media Preview Card
            </h4>
            <div className="border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm flex flex-col sm:flex-row bg-slate-50 dark:bg-slate-950">
              <img 
                src={ogImage} 
                alt="OG Preview" 
                className="w-full sm:w-28 h-28 object-cover object-center bg-slate-200 dark:bg-slate-800"
                referrerPolicy="no-referrer"
              />
              <div className="p-3.5 flex-1 flex flex-col justify-center">
                <span className="text-[10px] text-slate-400 dark:text-slate-500 font-mono tracking-wide">ALIAFFILIATE.STUDIO</span>
                <span className="font-bold text-xs text-slate-800 dark:text-slate-200 line-clamp-1 mt-0.5">{title}</span>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 mt-1 leading-snug">{description}</p>
              </div>
            </div>
          </div>

        </div>

        {/* Right Column: Google SERP Preview & Deployment instructions */}
        <div className="lg:col-span-6 space-y-6">
          
          {/* Mock Google Search Result */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-sans font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-1.5">
                <Search className="w-4.5 h-4.5 text-blue-500" />
                <span>Google Search Engine Simulator</span>
              </h3>
              
              <div className="flex rounded-lg bg-slate-100 dark:bg-slate-800 p-0.5 text-xs">
                <button
                  onClick={() => setPreviewDevice('desktop')}
                  className={`px-2.5 py-1 rounded-md font-semibold transition-all ${previewDevice === 'desktop' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-slate-400'}`}
                >
                  Desktop
                </button>
                <button
                  onClick={() => setPreviewDevice('mobile')}
                  className={`px-2.5 py-1 rounded-md font-semibold transition-all ${previewDevice === 'mobile' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-slate-400'}`}
                >
                  Mobile
                </button>
              </div>
            </div>

            {/* Simulated Google Listing Card */}
            <div className="p-5 bg-slate-50 dark:bg-slate-950 border border-slate-200/60 dark:border-slate-800/80 rounded-2xl font-sans">
              {previewDevice === 'desktop' ? (
                // Desktop google result layout
                <div className="space-y-1 max-w-[550px]">
                  <div className="text-xs text-slate-600 dark:text-slate-400 flex items-center gap-1">
                    <span>https://yourusername.github.io</span>
                    <span className="text-[10px] text-slate-400">&gt; aliexpress-affiliate</span>
                  </div>
                  <h4 className="text-[19px] text-blue-700 hover:underline cursor-pointer font-medium leading-tight dark:text-blue-400 truncate">
                    {title || "AliExpress Affiliate Store | Discover Premium Deals"}
                  </h4>
                  <p className="text-sm text-slate-600 dark:text-slate-350 leading-relaxed pt-0.5 line-clamp-2">
                    {description || "Explore curated high-quality electronics, accessories and smart home appliances on our dedicated affiliate portal. Fast shipping and protected checkouts."}
                  </p>
                  {/* Rich Snippets */}
                  <div className="flex items-center gap-1 text-xs text-slate-400 mt-1">
                    <span className="text-amber-500">★★★★★</span>
                    <span>Rating: 4.8 - ‎12 reviews - ‎Price range: $11.49 - $79.99</span>
                  </div>
                </div>
              ) : (
                // Mobile layout
                <div className="space-y-1.5 max-w-[360px]">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center text-slate-500 text-[10px] font-bold">
                      G
                    </div>
                    <div>
                      <div className="text-[11px] text-slate-800 dark:text-slate-300 font-bold leading-none">GitHub Pages</div>
                      <div className="text-[9px] text-slate-400 leading-none">yourusername.github.io</div>
                    </div>
                  </div>
                  <h4 className="text-base text-blue-700 dark:text-blue-400 hover:underline cursor-pointer font-medium leading-snug">
                    {title || "AliExpress Affiliate Store | Discover Premium Deals"}
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-350 leading-normal line-clamp-3">
                    {description || "Explore curated high-quality electronics, accessories and smart home appliances on our dedicated affiliate portal. Fast shipping and protected checkouts."}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* GitHub Pages Deployment instructions */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
            <h3 className="font-sans font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
              <Github className="w-5 h-5 text-slate-800 dark:text-slate-200" />
              <span>Easy GitHub Pages Deployment</span>
            </h3>
            
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
              Since this storefront is completely client-side and stores product configurations inside local storage, you can host it <strong>for 100% free</strong> on GitHub Pages in 3 steps!
            </p>

            <div className="space-y-3.5 pt-2 text-xs">
              <div className="flex gap-2.5 items-start">
                <span className="w-5 h-5 rounded-full bg-orange-100 text-orange-600 dark:bg-orange-500/10 dark:text-orange-400 font-bold flex items-center justify-center text-xs flex-shrink-0">1</span>
                <div>
                  <p className="font-bold text-slate-800 dark:text-slate-200">Install the deployment helper tool</p>
                  <p className="text-slate-400 dark:text-slate-500 mt-0.5">Run this single terminal command in your workspace root:</p>
                  <code className="block p-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg mt-1 font-mono text-[10px] break-all text-slate-700 dark:text-slate-400">
                    npm install gh-pages --save-dev
                  </code>
                </div>
              </div>

              <div className="flex gap-2.5 items-start">
                <span className="w-5 h-5 rounded-full bg-orange-100 text-orange-600 dark:bg-orange-500/10 dark:text-orange-400 font-bold flex items-center justify-center text-xs flex-shrink-0">2</span>
                <div>
                  <p className="font-bold text-slate-800 dark:text-slate-200">Add Deploy Scripts to package.json</p>
                  <p className="text-slate-400 dark:text-slate-500 mt-0.5">Insert the following deploy routines inside the scripts section:</p>
                  
                  <div className="relative mt-1">
                    <pre className="p-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg font-mono text-[9px] text-slate-700 dark:text-slate-400 overflow-x-auto">
                      {packageJsonScript}
                    </pre>
                    <button
                      onClick={handleCopyScript}
                      className="absolute top-2 right-2 p-1.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 text-slate-500 dark:text-slate-400 rounded hover:bg-slate-50 transition-all"
                      title="Copy Package Scripts"
                    >
                      {copiedScript ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex gap-2.5 items-start">
                <span className="w-5 h-5 rounded-full bg-orange-100 text-orange-600 dark:bg-orange-500/10 dark:text-orange-400 font-bold flex items-center justify-center text-xs flex-shrink-0">3</span>
                <div>
                  <p className="font-bold text-slate-800 dark:text-slate-200">Deploy your live shop!</p>
                  <p className="text-slate-400 dark:text-slate-500 mt-0.5">Build and deploy automatically to GitHub with this command:</p>
                  <code className="block p-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg mt-1 font-mono text-[10px] break-all text-slate-700 dark:text-slate-400">
                    npm run deploy
                  </code>
                  <p className="text-[10px] text-emerald-600 dark:text-emerald-500 font-medium mt-1">
                    ✓ Your store is now active and live worldwide at <strong>https://yourusername.github.io/repo-name/</strong>!
                  </p>
                </div>
              </div>
            </div>

          </div>

          {/* Compiled head tags code output */}
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl border border-slate-100 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-sans font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                <FileCode className="w-4 h-4 text-emerald-500" />
                <span>Generated Head Meta Tags HTML</span>
              </h3>

              <button
                onClick={handleCopyMeta}
                className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 rounded-lg text-[11px] font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1 transition-all"
              >
                {copiedMeta ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedMeta ? 'Copied' : 'Copy Head Code'}</span>
              </button>
            </div>

            <pre className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-850 rounded-xl font-mono text-[9px] text-slate-750 dark:text-slate-400 overflow-x-auto max-h-40">
              {compiledMetaCode}
            </pre>
          </div>

        </div>

      </div>

    </div>
  );
}
