import React, { useState } from 'react';
import { 
  X, 
  Star, 
  ExternalLink, 
  Heart, 
  FileText, 
  MessageSquare, 
  Link as LinkIcon, 
  Copy, 
  Check, 
  ShieldCheck, 
  Truck 
} from 'lucide-react';
import { Product, AffiliateConfig } from '../types';
import { getAffiliateLink, formatPrice } from '../utils/helpers';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  affiliateConfig: AffiliateConfig;
}

type ModalTab = 'specifications' | 'reviews' | 'affiliate';

export default function ProductModal({
  product,
  onClose,
  isWishlisted,
  onToggleWishlist,
  affiliateConfig
}: ProductModalProps) {
  if (!product) return null;

  const [activeTab, setActiveTab] = useState<ModalTab>('specifications');
  const [copied, setCopied] = useState(false);

  const affiliateLink = getAffiliateLink(product.aliexpressUrl, affiliateConfig);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(affiliateLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Render Stars
  const renderStars = (rating: number, size = "w-4 h-4") => {
    const stars = [];
    const fullStars = Math.floor(rating);
    for (let i = 1; i <= 5; i++) {
      if (i <= fullStars) {
        stars.push(<Star key={i} className={`${size} fill-amber-400 text-amber-400`} />);
      } else {
        stars.push(<Star key={i} className={`${size} text-slate-300 dark:text-slate-600`} />);
      }
    }
    return stars;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm transition-opacity" 
        onClick={onClose}
        id="modal-backdrop"
      ></div>

      {/* Modal Container */}
      <div className="flex min-h-screen items-center justify-center p-4 text-center sm:p-0">
        <div className="relative transform overflow-hidden rounded-3xl bg-white text-left shadow-2xl transition-all sm:my-8 sm:w-full sm:max-w-4xl dark:bg-slate-900 border border-slate-100 dark:border-slate-800">
          
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-5 right-5 z-20 p-2 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-800 dark:hover:text-white transition-all"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Modal Grid content */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-0">
            
            {/* Left Column: Image Area */}
            <div className="md:col-span-5 bg-slate-50 dark:bg-slate-950 p-6 flex flex-col justify-center items-center relative border-b md:border-b-0 md:border-r border-slate-100 dark:border-slate-800/80">
              <div className="aspect-square w-full max-w-[320px] rounded-2xl overflow-hidden shadow-sm bg-white dark:bg-slate-900 p-2 flex items-center justify-center">
                <img
                  src={product.imageUrl}
                  alt={product.title}
                  referrerPolicy="no-referrer"
                  className="object-cover w-full h-full rounded-xl"
                />
              </div>

              {/* Badges in Image Section */}
              <div className="mt-4 flex flex-wrap gap-2 justify-center">
                <span className="text-xs bg-red-100 text-red-800 dark:bg-red-950/40 dark:text-red-400 font-bold px-2.5 py-1 rounded-full border border-red-200/50 dark:border-red-900/50">
                  {product.discount}% OFF Coupon Active
                </span>
                <span className="text-xs bg-emerald-50 text-emerald-800 dark:bg-emerald-950/40 dark:text-emerald-400 font-bold px-2.5 py-1 rounded-full border border-emerald-200/50 dark:border-emerald-900/50 flex items-center gap-1">
                  <Truck className="w-3.5 h-3.5" /> Free Shipping
                </span>
              </div>
            </div>

            {/* Right Column: Detailed Specs and CTA */}
            <div className="md:col-span-7 p-6 sm:p-8 flex flex-col max-h-[90vh] overflow-y-auto">
              
              {/* Category Breadcrumb */}
              <span className="text-xs text-orange-600 dark:text-orange-400 font-extrabold uppercase tracking-widest mb-2 block">
                {product.category}
              </span>

              {/* Title */}
              <h2 className="font-sans font-extrabold text-xl sm:text-2xl text-slate-900 dark:text-white leading-snug">
                {product.title}
              </h2>

              {/* Star Ratings */}
              <div className="flex items-center gap-2 mt-3">
                <div className="flex gap-0.5">
                  {renderStars(product.rating)}
                </div>
                <span className="text-sm font-bold text-slate-700 dark:text-slate-300">
                  {product.rating} / 5.0
                </span>
                <span className="text-xs text-slate-400 dark:text-slate-500">
                  ({product.reviewsCount} customer ratings)
                </span>
              </div>

              {/* Pricing Grid */}
              <div className="mt-5 p-4 bg-slate-50 dark:bg-slate-800/40 rounded-2xl flex items-center justify-between border border-slate-100 dark:border-slate-800/50">
                <div>
                  <span className="text-xs text-slate-400 dark:text-slate-500 block">Original AliExpress Price</span>
                  <span className="text-sm text-slate-400 dark:text-slate-500 line-through">
                    {formatPrice(product.originalPrice)}
                  </span>
                </div>
                
                <div className="text-right">
                  <span className="text-xs text-orange-600 dark:text-orange-400 font-bold block">Best Promo Deal</span>
                  <span className="text-2xl font-black text-orange-600 dark:text-orange-500">
                    {formatPrice(product.price)}
                  </span>
                </div>
              </div>

              {/* Direct Affiliate Redirect CTA Block */}
              <div className="mt-6 flex flex-col sm:flex-row gap-3">
                <a
                  href={affiliateLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 py-3.5 px-6 bg-gradient-to-r from-orange-500 via-orange-600 to-red-600 hover:from-orange-600 hover:to-red-700 text-white rounded-2xl font-bold text-sm text-center shadow-lg shadow-orange-500/20 hover:shadow-orange-500/30 transition-all flex items-center justify-center gap-2"
                >
                  <span>Buy Direct on AliExpress</span>
                  <ExternalLink className="w-4 h-4" />
                </a>

                <button
                  onClick={() => onToggleWishlist(product)}
                  className={`py-3.5 px-5 rounded-2xl border font-bold text-sm transition-all flex items-center justify-center gap-2 ${
                    isWishlisted
                      ? 'bg-red-50 border-red-200 text-red-500 dark:bg-red-950/20 dark:border-red-900/50'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-700'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-red-500' : ''}`} />
                  <span>{isWishlisted ? 'Wishlisted' : 'Save'}</span>
                </button>
              </div>

              {/* Buyer protection warning */}
              <p className="mt-2.5 text-[11px] text-slate-400 dark:text-slate-500 flex items-center gap-1 px-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0" />
                <span>AliExpress Buyer Protection included. Safe, secure, encrypted global checkout.</span>
              </p>

              {/* Key Features Bullet points */}
              <div className="mt-6">
                <h4 className="font-sans font-bold text-xs text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-3">
                  Key Curated Features
                </h4>
                <ul className="space-y-2 text-xs text-slate-600 dark:text-slate-300">
                  {product.features.map((feat, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-1.5 flex-shrink-0" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Tabs Section */}
              <div className="mt-8 border-b border-slate-100 dark:border-slate-800">
                <div className="flex gap-4">
                  {(['specifications', 'reviews', 'affiliate'] as const).map((tab) => (
                    <button
                      key={tab}
                      onClick={() => setActiveTab(tab)}
                      className={`pb-3 text-xs font-bold uppercase tracking-wider relative transition-all ${
                        activeTab === tab 
                          ? 'text-orange-600 dark:text-orange-400' 
                          : 'text-slate-400 hover:text-slate-600 dark:text-slate-500 dark:hover:text-slate-400'
                      }`}
                    >
                      <span className="flex items-center gap-1.5">
                        {tab === 'specifications' && <FileText className="w-3.5 h-3.5" />}
                        {tab === 'reviews' && <MessageSquare className="w-3.5 h-3.5" />}
                        {tab === 'affiliate' && <LinkIcon className="w-3.5 h-3.5" />}
                        {tab === 'specifications' && 'Specs'}
                        {tab === 'reviews' && 'Reviews'}
                        {tab === 'affiliate' && 'Tracking Info'}
                      </span>
                      {activeTab === tab && (
                        <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-500 rounded-full" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Tab Outputs */}
              <div className="py-4 flex-1">
                {activeTab === 'specifications' && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3">
                    {Object.entries(product.specifications).map(([key, val]) => (
                      <div key={key} className="border-b border-slate-50 dark:border-slate-800/40 pb-2 text-xs">
                        <span className="text-slate-400 dark:text-slate-500 font-medium block">{key}</span>
                        <span className="text-slate-800 dark:text-slate-200 font-bold">{val}</span>
                      </div>
                    ))}
                  </div>
                )}

                {activeTab === 'reviews' && (
                  <div className="space-y-4">
                    {product.reviews.map((rev, index) => (
                      <div key={index} className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl text-xs">
                        <div className="flex items-center justify-between mb-1.5">
                          <div className="flex items-center gap-2">
                            <div className="w-6 h-6 rounded-full bg-orange-100 text-orange-700 font-bold flex items-center justify-center dark:bg-orange-900/30 dark:text-orange-400 text-[10px]">
                              {rev.author.charAt(0)}
                            </div>
                            <span className="font-bold text-slate-800 dark:text-slate-200">{rev.author}</span>
                          </div>
                          <span className="text-[10px] text-slate-400 dark:text-slate-500">{rev.date}</span>
                        </div>
                        <div className="flex gap-0.5 mb-1">
                          {renderStars(rev.rating, "w-3 h-3")}
                        </div>
                        <p className="text-slate-600 dark:text-slate-300 italic">
                          "{rev.comment}"
                        </p>
                      </div>
                    ))}
                  </div>
                )}

                {activeTab === 'affiliate' && (
                  <div className="space-y-3 bg-orange-50/50 dark:bg-orange-950/10 p-4 rounded-xl border border-orange-100 dark:border-orange-900/30 text-xs">
                    <p className="text-orange-800 dark:text-orange-400 font-semibold flex items-center gap-1.5 mb-2">
                      <ShieldCheck className="w-4 h-4" /> Affiliate URL Construction
                    </p>
                    
                    <div className="space-y-2">
                      <div>
                        <span className="text-slate-400 dark:text-slate-500 block font-medium">Base URL:</span>
                        <code className="block p-1.5 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded font-mono text-[10px] break-all text-slate-600 dark:text-slate-400">
                          {product.aliexpressUrl}
                        </code>
                      </div>

                      <div>
                        <span className="text-slate-400 dark:text-slate-500 block font-medium">Configured Tracking Parameter:</span>
                        <span className="font-bold text-slate-800 dark:text-slate-200">
                          {affiliateConfig.appendMethod === 'param' 
                            ? `?${affiliateConfig.trackingParamName}=${affiliateConfig.trackingId || 'not_set'}` 
                            : 'Template Redirection System'
                          }
                        </span>
                      </div>

                      <div>
                        <span className="text-slate-400 dark:text-slate-500 block font-medium">Active Outbound Link:</span>
                        <div className="flex gap-2 items-center">
                          <code className="flex-1 block p-1.5 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded font-mono text-[10px] break-all text-orange-600 dark:text-orange-400">
                            {affiliateLink}
                          </code>
                          <button
                            onClick={handleCopyLink}
                            className="p-2 bg-white hover:bg-slate-50 dark:bg-slate-800 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white transition-all flex-shrink-0"
                            title="Copy Generated Link"
                          >
                            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                        {copied && <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold mt-1 block">Copied to clipboard!</span>}
                      </div>
                    </div>
                  </div>
                )}
              </div>

            </div>

          </div>

        </div>
      </div>
    </div>
  );
}
