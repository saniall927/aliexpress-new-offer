import React, { useState } from 'react';
import { 
  ShoppingBag, 
  Heart, 
  Settings, 
  Moon, 
  Sun, 
  Search, 
  Menu, 
  X, 
  Globe,
  Sparkles
} from 'lucide-react';

interface NavbarProps {
  currentTab: 'shop' | 'wishlist' | 'affiliate' | 'seo';
  setCurrentTab: (tab: 'shop' | 'wishlist' | 'affiliate' | 'seo') => void;
  wishlistCount: number;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  darkMode: boolean;
  toggleDarkMode: () => void;
}

export default function Navbar({
  currentTab,
  setCurrentTab,
  wishlistCount,
  searchQuery,
  setSearchQuery,
  darkMode,
  toggleDarkMode
}: NavbarProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'shop' as const, label: 'Curated Shop', icon: ShoppingBag },
    { id: 'wishlist' as const, label: 'My Wishlist', icon: Heart, count: wishlistCount },
    { id: 'affiliate' as const, label: 'Affiliate Portal', icon: Settings },
    { id: 'seo' as const, label: 'SEO Studio', icon: Globe },
  ];

  return (
    <nav className="sticky top-0 z-40 bg-white/95 border-b border-slate-200 backdrop-blur-md dark:bg-slate-900/95 dark:border-slate-800 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Logo & Brand */}
          <div 
            onClick={() => { setCurrentTab('shop'); setMobileMenuOpen(false); }} 
            className="flex items-center gap-2 cursor-pointer group flex-shrink-0"
            id="navbar-brand"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-orange-500 to-red-600 flex items-center justify-center text-white shadow-md shadow-orange-500/20 group-hover:scale-105 transition-transform">
              <ShoppingBag className="w-5.5 h-5.5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-sans font-extrabold text-xl tracking-tight bg-gradient-to-r from-orange-600 to-red-600 dark:from-orange-500 dark:to-red-500 bg-clip-text text-transparent">
                  AliExpress
                </span>
                <span className="text-xs bg-red-100 text-red-700 px-1.5 py-0.5 rounded-full font-bold dark:bg-red-900/40 dark:text-red-400 border border-red-200 dark:border-red-800">
                  Affiliate
                </span>
              </div>
              <p className="text-[10px] text-slate-400 dark:text-slate-500 font-medium -mt-1 tracking-wider uppercase">
                Premium Storefront
              </p>
            </div>
          </div>

          {/* Search Box (Desktop) */}
          <div className="hidden md:flex flex-1 max-w-md mx-4 relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-slate-400" />
            </div>
            <input
              type="text"
              id="desktop-search-input"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (currentTab !== 'shop') {
                  setCurrentTab('shop');
                }
              }}
              placeholder="Search premium tech, home decor, electronics..."
              className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-xl bg-slate-50 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 dark:bg-slate-800/50 dark:border-slate-700 dark:text-slate-100 dark:placeholder-slate-500 transition-all text-sm"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          {/* Navigation Links & Controls (Desktop) */}
          <div className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => {
              const IconComponent = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-tab-${item.id}`}
                  onClick={() => setCurrentTab(item.id)}
                  className={`relative flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold transition-all duration-200 ${
                    isActive 
                      ? 'bg-orange-50 text-orange-600 dark:bg-orange-500/10 dark:text-orange-400' 
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-slate-100'
                  }`}
                >
                  <IconComponent className="w-4.5 h-4.5" />
                  <span>{item.label}</span>
                  {item.count !== undefined && item.count > 0 && (
                    <span className="ml-1.5 px-2 py-0.5 text-xs font-bold bg-orange-500 text-white rounded-full leading-none shadow-sm animate-pulse">
                      {item.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Quick Tools (Theme & Mobile Menu) */}
          <div className="flex items-center gap-2">
            <button
              onClick={toggleDarkMode}
              id="theme-toggle-btn"
              aria-label="Toggle dark mode"
              className="p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-400 dark:hover:text-slate-100 dark:hover:bg-slate-800 rounded-xl border border-slate-200/55 dark:border-slate-800/55 transition-colors"
            >
              {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>

            {/* Cart/Wishlist quick button for mobile layout */}
            <button
              onClick={() => setCurrentTab('wishlist')}
              id="wishlist-quick-btn"
              className="lg:hidden p-2 relative text-slate-500 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-400 dark:hover:text-slate-100 dark:hover:bg-slate-800 rounded-xl border border-slate-200/55 dark:border-slate-800/55 transition-colors"
            >
              <Heart className={`w-5 h-5 ${wishlistCount > 0 ? 'fill-orange-500 text-orange-500' : ''}`} />
              {wishlistCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-4.5 w-4.5 items-center justify-center rounded-full bg-orange-600 text-[10px] font-bold text-white shadow-sm">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-500 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-400 dark:hover:text-slate-100 dark:hover:bg-slate-800 rounded-xl border border-slate-200/55 dark:border-slate-800/55 transition-colors"
              id="mobile-menu-toggle-btn"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Search & Navigation Panel */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white dark:bg-slate-900 dark:border-slate-800 py-4 px-4 space-y-4 shadow-xl">
          {/* Mobile Search Box */}
          <div className="relative md:hidden w-full">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-slate-400" />
            </div>
            <input
              type="text"
              id="mobile-search-input"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (currentTab !== 'shop') {
                  setCurrentTab('shop');
                }
              }}
              placeholder="Search premium tech, gadgets..."
              className="w-full pl-10 pr-4 py-2 border border-slate-200 rounded-xl bg-slate-50 text-slate-900 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 dark:bg-slate-800/50 dark:border-slate-700 dark:text-slate-100 dark:placeholder-slate-500 transition-all text-sm"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          {/* Navigation Links */}
          <div className="flex flex-col gap-1">
            {navItems.map((item) => {
              const IconComponent = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center justify-between w-full px-4 py-3 rounded-xl text-base font-semibold transition-all ${
                    isActive 
                      ? 'bg-orange-50 text-orange-600 dark:bg-orange-500/10 dark:text-orange-400' 
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <IconComponent className="w-5 h-5" />
                    <span>{item.label}</span>
                  </div>
                  {item.count !== undefined && item.count > 0 && (
                    <span className="px-2.5 py-0.5 text-xs font-bold bg-orange-500 text-white rounded-full">
                      {item.count}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-400 dark:text-slate-500 px-2">
            <span>Powered by Smart Affiliate System</span>
            <span>v1.0.4</span>
          </div>
        </div>
      )}
    </nav>
  );
}
